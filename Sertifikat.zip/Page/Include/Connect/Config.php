<?php
$username = "root";
$password = "aris";
$database = "sertifikat";
$host_name = "localhost";
//$con = mysqli_connect($host_name, base64_decode($username), base64_decode($password));
$con = mysqli_connect($host_name, $username, $password);
//phpinfo();

?>